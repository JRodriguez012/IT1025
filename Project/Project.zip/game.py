import math
import random
import time
import pygame

# define window dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 800

# define player class
class Player(pygame.sprite.Sprite):

    def __init__(self, x, y):

        # call Sprite initializer
        pygame.sprite.Sprite.__init__(self)

        # initialize attributes of the Sprite base class
        self.image = pygame.image.load("./sprites/char.png")
        self.rect = pygame.Rect(0, 0, 32, 32)
        self.rect.center = (x, y)

        # define the portion of spritesheet to draw
        self.texture_rect = pygame.Rect(0, 0, self.rect.width, self.rect.height)

        # create sprite group for bullets
        self.bullet_group = pygame.sprite.Group()

        self.speed = 5  # movement speed

        self.shot_delay = 0.1    # time between shots
        self.last_shot = 0.0     # time of last 
        
        self.is_alive = True

    def update(self):

        # get the positions of the player and the mouse
        mouse_pos = pygame.math.Vector2(pygame.mouse.get_pos())
        player_pos = pygame.math.Vector2(self.rect.centerx, self.rect.centery)

        # find the direction and angle between the mouse and player
        dir = mouse_pos - player_pos
        angle = math.atan2(dir.y, dir.x)

        self.look_at_mouse(angle)

        # check if player is alive
        if self.is_alive:
            # check if left mouse button is down
            if pygame.mouse.get_pressed()[0]:
                # check if time is past the delay between shots
                if time.time() - self.last_shot > self.shot_delay:
                    dir_len = dir.length()
                    if(dir_len != 0):
                        self.shoot(dir.normalize()) # shoot in direction of mouse
                        self.last_shot = time.time()  # set time of last shot
        
        # update bullets 
        self.bullet_group.update()

    def draw(self, screen):
        self.bullet_group.draw(screen)  # draw bullets under player
        screen.blit(self.image, self.rect, self.texture_rect)

    def move(self, x, y):
        
        # check if player is alive
        if self.is_alive:
            # change in x and y positions
            dx = x * self.speed
            dy = y * self.speed

            # check if the player will not go past the edges of the screen
            if((self.rect.left + dx > 0 and self.rect.right + dx < SCREEN_WIDTH) and
                (self.rect.top + dy > 0 and self.rect.bottom + dy < SCREEN_HEIGHT)):
                self.rect = self.rect.move(dx, dy)

    def look_at_mouse(self, angle):

        # swap the visible portion of spritesheet to based on the angle between mouse and player
        if(angle < math.pi/6 and angle > -math.pi/6):
            self.texture_rect = pygame.Rect(0, 0, self.rect.width,self.rect.height)    # RIGHT
        elif(angle < -math.pi/6 and angle > -math.pi/3):
            self.texture_rect = pygame.Rect(32, 0, self.rect.width, self.rect.height)  # UPRIGHT
        elif(angle < -math.pi/3 and angle > -2*math.pi/3):
            self.texture_rect = pygame.Rect(64, 0, self.rect.width, self.rect.height)  # UP
        elif(angle < -2*math.pi/3 and angle > -5*math.pi/6):
            self.texture_rect = pygame.Rect(0, 32, self.rect.width, self.rect.height)  # UPLEFT
        elif(angle < -5*math.pi/6 or angle > 5*math.pi/6):
            self.texture_rect = pygame.Rect(32, 32, self.rect.width, self.rect.height) # LEFT
        elif(angle < 5*math.pi/6 and angle > 2*math.pi/3):
            self.texture_rect = pygame.Rect(64, 32, self.rect.width, self.rect.height) # DOWNLEFT
        elif(angle < 2*math.pi/3 and angle > math.pi/3):
            self.texture_rect = pygame.Rect(0, 64, self.rect.width, self.rect.height)  # DOWN
        else:
            self.texture_rect = pygame.Rect(32, 64, 32, 32)                            # DOWNRIGHT

    def shoot(self, dir):

        # create a bullet and add it to the bullet group
        bullet = Bullet(self.rect.centerx, self.rect.centery, dir)
        self.bullet_group.add(bullet)

# define bullet class
class Bullet(pygame.sprite.Sprite):

    def __init__(self, x, y, dir):
        # call Sprite initializer
        pygame.sprite.Sprite.__init__(self)

        # initalzie Sprite attributes
        self.image = pygame.image.load("./sprites/bullet.png")
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

        self.speed = 20     # speed of bullet
        self.dir = dir      # direction of bullet

    def update(self):

        # move the bullet in direction with speed
        self.rect = self.rect.move(self.dir[0] * self.speed, self.dir[1] * self.speed)

        # check if the bullet goes off screen
        if ((self.rect.right < 0 or self.rect.left > SCREEN_WIDTH) or 
            (self.rect.bottom < 0 or self.rect.top > SCREEN_HEIGHT)):
            self.kill()     # destroy bullet

# defines the enemy class
class Enemy(pygame.sprite.Sprite):

    def __init__(self, x, y, player):

        # call Sprite initializer
        pygame.sprite.Sprite.__init__(self)

        # initialize Sprite attributes
        self.image = pygame.image.load("./sprites/enemy.png")
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

        self.player = player # used to keep track of player position
        self.speed = 3      # movement speed

    def update(self):

        # always follow player
        self.move_towards_player()

        # check if enemy collides with a bullet
        if pygame.sprite.spritecollide(self, self.player.bullet_group, True):
            self.kill()     # destroy enemy

        if pygame.sprite.collide_rect(self, self.player):
            if self.player.is_alive:
                pygame.time.set_timer(pygame.QUIT, 3000)
                self.player.is_alive = False

    def move_towards_player(self):

        # get enemy and player positions
        enemy_pos = pygame.math.Vector2(self.rect.centerx, self.rect.centery)
        player_pos = pygame.math.Vector2(self.player.rect.centerx, self.player.rect.centery)

        # get the direction between player and enemy positions
        dir = (player_pos - enemy_pos)

        # cannot normalize a vector of length zero
        dir_len = dir.length()
        if dir_len != 0:
            dir = dir.normalize()  # only need direction
        
        # move enemy in direction of player with speed
        self.rect = self.rect.move(dir[0] * self.speed, dir[1] * self.speed)

# define the game class
class Game:

    def __init__(self):

        # initalize the pygame module
        pygame.init()

        # set the window name
        pygame.display.set_caption("SHOOTER")

        # create a surface on screen with proper dimensions
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

        # controls the frame rate
        self.clock = pygame.time.Clock()

        # enemy spawn timer
        pygame.time.set_timer(pygame.USEREVENT, 3000)

        self.player = Player(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2)
        self.enemy_group = pygame.sprite.Group()

    # runs the main game loop
    def run(self):

        # controls the main game loop
        self.is_running = True

        # main game loop
        while self.is_running:
            self.clock.tick(60)

            self.process_input()
            self.update()
            self.render()

    # handles game events and inputs
    def process_input(self):

        # gets all events from the event queue
        for event in pygame.event.get():
                # quits game if event is of type QUIT
                if event.type == pygame.QUIT:
                    self.is_running = False
                elif event.type == pygame.USEREVENT:
                    self.spawn_enemy()
                    
        # gets the state of the keyboard
        keys = pygame.key.get_pressed()

        # handle keyboard presses
        if keys[pygame.K_w]:
            self.player.move(0, -1)
        if keys[pygame.K_a]:
            self.player.move(-1, 0)
        if keys[pygame.K_s]:
            self.player.move(0, 1)
        if keys[pygame.K_d]:
            self.player.move(1, 0)

    # update state of game objects
    def update(self):
        self.player.update()
        self.enemy_group.update()

    # draw game objects to the screen
    def render(self):

        # erase the screen
        self.screen.fill((0, 0, 0))

        # draw game objects
        self.player.draw(self.screen)
        self.enemy_group.draw(self.screen)

        # update the screen
        pygame.display.flip()

    # spawns an enemy in a random position
    def spawn_enemy(self):

        # get random x and y coordinates
        random_x = random.randint(0, SCREEN_WIDTH)
        random_y = random.randint(0, SCREEN_HEIGHT)

        # create and enemy at random position and add it to enemy group
        enemy = Enemy(random_x, random_y, self.player)
        self.enemy_group.add(enemy)

    def quit(self):
        pygame.display.quit()
        pygame.quit()

# main loop
def main():
    game = Game()
    game.run()
    game.quit()

if __name__=="__main__":
    main()